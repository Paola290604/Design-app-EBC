//Desafío de las cajas//

// Desafío 1: cambiar el título con getElementById //


document.getElementById("btn-titulo").addEventListener("click", ()=> 
{
  const titulo = 
        document.getElementById("titulo");
  titulo.textContent = "El título ha sido cambiado";
  
});

//Desafío 2: cambiar el color de las cajas .getElementsByClassName //

document.getElementById("btn-cajas").addEventListener("click",()=>   
{
  const cajas=
        document.getElementsByClassName("caja")
        for (let i = 0; i < cajas.length; i++)
          {
            cajas[i].style.backgroundColor="#B8FFF2";
          }
}); 

// Desafio 3: Cambiar color de solo una caja con .querySelector //
document.getElementById("btn-primera").addEventListener("click",()=>
                                                     {                                                  const primeracaja =
   document.querySelector(".caja");
                                                      
primeracaja.style.backgroundColor = "#5BEBAF";
                                                      });


// Desafío 4: querySelectorAll() cambiarle el borde a todas las cajas //

document.getElementById("btn-bordes").addEventListener("click",()=>
 {
  const cajas=
        document.querySelectorAll(".caja");
  cajas.forEach(caja=>{
    caja.style.border="4px solid blue"
  });
});                                                      